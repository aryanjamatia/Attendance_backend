import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import authRoutes from "./routes/auth.js";
import classroomRoutes from "./routes/classroom.js";

const app = express();

app.use(cors());
app.use(express.json());

// ✅ CONNECT ROUTES
app.use("/api/auth", authRoutes);
app.use("/api/classroom", classroomRoutes);

mongoose.connect("mongodb://127.0.0.1:27017/attendance")
  .then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

app.get("/", (req, res) => {
  res.send("API Running");
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});