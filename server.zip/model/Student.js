import mongoose from "mongoose";

const studentSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  password: String,
  rollNo: String,
  course: String,
  semester: String,
});

const Student = mongoose.model("Student", studentSchema);

export default Student;