import express from "express";
import Student from "../model/Student.js";
import Teacher from "../model/Teacher.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const router = express.Router();

// 🔐 REGISTER
router.post("/register", async (req, res) => {
  try {
    const { role, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    let user;

    if (role === "student") {
      user = await Student.create({
        ...req.body,
        password: hashedPassword,
      });
    } else if (role === "teacher") {
      user = await Teacher.create({
        ...req.body,
        password: hashedPassword,
      });
    } else {
      return res.status(400).json({ message: "Invalid role" });
    }

    res.json({ message: "Registered successfully", user });

  } catch (err) {
    console.log(err);
    res.status(500).json({ error: err.message });
  }
});

// 🔐 LOGIN
router.post("/login", async (req, res) => {
  try {
    const { email, password, role } = req.body;

    let user;

    if (role === "student") {
      user = await Student.findOne({ email });
    } else if (role === "teacher") {
      user = await Teacher.findOne({ email });
    }

    if (!user) return res.status(400).json({ msg: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: "Invalid password" });

    const token = jwt.sign(
      { id: user._id, role },
      "SECRET_KEY",
      { expiresIn: "1d" }
    );

    res.json({ token, user });

  } catch (err) {
    console.log(err);
    res.status(500).json({ error: err.message });
  }
});

// 🔐 GET PROFILE (ADD THIS)
router.get("/profile", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      return res.status(401).json({ msg: "No token provided" });
    }

    const token = authHeader.split(" ")[1];

    const decoded = jwt.verify(token, "SECRET_KEY");

    let user;

    if (decoded.role === "teacher") {
      user = await Teacher.findById(decoded.id).select("-password");
    } else {
      user = await Student.findById(decoded.id).select("-password");
    }

    res.json(user);

  } catch (err) {
    console.log(err);
    res.status(401).json({ msg: "Invalid token" });
  }
});

export default router;